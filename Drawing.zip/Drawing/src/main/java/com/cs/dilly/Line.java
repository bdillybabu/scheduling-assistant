package com.cs.dilly;

import java.util.Set;

public class Line implements Shape {

    private Set<Point> shapeCoordinates = null;

    Line(Set<Point> shapeCoordinates) {
        this.shapeCoordinates = shapeCoordinates;
    }

    public void draw(int x1, int y1, int x2, int y2, int yMax) {
        x1 = x1 + 1;
        x2 = x2 + 1;
        for (int x = x1; x <= x2; x++) {
            for (int y = y2; y >= y1; y--) {
                this.getShapeCoordinates().add(new Point(x, (yMax - y)));
            }
        }
    }

    public Set<Point> getShapeCoordinates() {
        return shapeCoordinates;
    }
}
