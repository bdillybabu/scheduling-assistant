package com.cs.dilly;

public enum Command {

    CANVAS("C"),
    LINE("L"),
    RECTANGE("R"),
    BUCKET_FILL("B");

    private String code;

    Command(String code) {
        this.code = code;
    }

    public static Command getCommand(String code) {
        for (Command cmd : Command.values()) {
            if (cmd.getCode().equals(code.toUpperCase())) {
                return cmd;
            }
        }
        return null;
    }

    public String getCode() {
        return code;
    }
}
