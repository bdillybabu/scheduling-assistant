package com.cs.dilly;

import java.util.Set;

public class Rectangle implements Shape {

    private Set<Point> shapeCoordinates = null;

    Rectangle(Set<Point> shapeCoordinates) {
        this.shapeCoordinates = shapeCoordinates;
    }

    public void draw(int x1, int y1, int x2, int y2, int yMax) {
        Shape shape = new Line(this.getShapeCoordinates());
        shape.draw(x1, y1, x2, y1, yMax);
        shape.draw(x1, y1, x1, y2, yMax);
        shape.draw(x1, y2, x2, y2, yMax);
        shape.draw(x2, y1, x2, y2, yMax);
    }

    public Set<Point> getShapeCoordinates() {
        return shapeCoordinates;
    }
}
