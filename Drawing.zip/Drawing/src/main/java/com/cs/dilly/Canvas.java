package com.cs.dilly;

import java.util.HashSet;
import java.util.Set;

public class Canvas {

    private static final String X = "x";
    private static final String PIPE = "|";
    private static final String UNDER_SCORE = "-";
    private static final String SPACE = " ";

    private Set<Point> shapeCoordinates = new HashSet<>();
    private Set<Point> colorCoordinates = new HashSet<>();
    private int xMax = 0;
    private int xMin = 0;
    private int yMax = 0;
    private int yMin = 0;
    private String colour = null;

    public void receiveCommand(String commands) {

        String[] inputs = commands.trim().split("\\s+");

        switch (Command.getCommand(inputs[0])) {

            case CANVAS:
                createCanvas(
                        Integer.parseInt(String.valueOf(inputs[1])),
                        Integer.parseInt(String.valueOf(inputs[2])));
                break;
            case LINE:
                Shape line = new Line(this.getShapeCoordinates());
                line.draw(
                        Integer.parseInt(String.valueOf(inputs[1])),
                        Integer.parseInt(String.valueOf(inputs[2])),
                        Integer.parseInt(String.valueOf(inputs[3])),
                        Integer.parseInt(String.valueOf(inputs[4])),
                        this.getyMax()
                );
                break;
            case RECTANGE:
                Shape rectangle = new Rectangle(this.getShapeCoordinates());
                rectangle.draw(
                        Integer.parseInt(String.valueOf(inputs[1])),
                        Integer.parseInt(String.valueOf(inputs[2])),
                        Integer.parseInt(String.valueOf(inputs[3])),
                        Integer.parseInt(String.valueOf(inputs[4])),
                        this.getyMax());
                break;
            case BUCKET_FILL:
                Bucket bucket = new Bucket(shapeCoordinates, colorCoordinates, xMax, xMin, yMax, yMin);
                bucket.fill(Integer.parseInt(String.valueOf(inputs[1])),
                        Integer.parseInt(String.valueOf(inputs[2])));
                this.setColour(inputs[3]);
                break;
            default:
                System.out.println("Unknow Command. Please try again.....");
        }
        printCordinates();

    }

    private void createCanvas(int width, int height) {
        this.setxMax(width + 2);
        this.setxMin(1);
        this.setyMax(height + 2);
        this.setyMin(1);
    }

    private void printCordinates() {
        for (int y = yMax; y >= yMin; y--) {
            for (int x = xMin; x <= xMax; x++) {
                Point point = new Point(x, y);
                System.out.print(
                        (y == yMax || y == yMin) ?
                                UNDER_SCORE : (x == xMax || x == xMin) ?
                                PIPE : this.getShapeCoordinates().contains(point) ?
                                X : this.getColorCoordinates().contains(point) ?
                                this.getColour() : SPACE);
            }
            System.out.println();
        }
    }


    public void setxMax(int xMax) {
        this.xMax = xMax;
    }

    public void setxMin(int xMin) {
        this.xMin = xMin;
    }

    public int getyMax() {
        return yMax;
    }

    public void setyMax(int yMax) {
        this.yMax = yMax;
    }

    public void setyMin(int yMin) {
        this.yMin = yMin;
    }

    public Set<Point> getColorCoordinates() {
        return colorCoordinates;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public Set<Point> getShapeCoordinates() {
        return shapeCoordinates;
    }
}
