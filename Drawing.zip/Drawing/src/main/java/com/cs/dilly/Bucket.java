package com.cs.dilly;

import java.util.Set;

public class Bucket {

    private Set<Point> shapeCoordinates;
    private Set<Point> colorCoordinates;
    private int xMax;
    private int xMin;
    private int yMax;
    private int yMin;

    public Bucket(Set<Point> shapeCoordinates, Set<Point> colorCoordinates, int xMax, int xMin, int yMax, int yMin) {
        this.shapeCoordinates = shapeCoordinates;
        this.colorCoordinates = colorCoordinates;
        this.xMax = xMax;
        this.xMin = xMin;
        this.yMax = yMax;
        this.yMin = yMin;
    }

    public void fill(int x, int y) {
        x = x + 1;
        y = y + 1;
        Point point = null;
        for (int j = y; j <= yMax; j++) {
            point = new Point(x, j);
            if (this.getShapeCoordinates().contains(point)) {
                break;
            }
            for (int i = x; i < xMax; i++) {
                point = new Point(i, j);
                if (this.getShapeCoordinates().contains(point)) {
                    break;
                }
                this.setColorCoordinates(point);
            }
            for (int i = (x - 1); i > xMin; i--) {
                point = new Point(i, j);
                if (this.getShapeCoordinates().contains(point)) {
                    break;
                }
                this.setColorCoordinates(point);
            }
        }
        for (int j = (y - 1); j > yMin; j--) {
            point = new Point(x, j);
            if (this.getShapeCoordinates().contains(point)) {
                break;
            }
            for (int i = x; i < xMax; i++) {
                point = new Point(i, j);
                if (this.getShapeCoordinates().contains(point)) {
                    break;
                }
                this.setColorCoordinates(point);
            }
            for (int i = (x - 1); i > xMin; i--) {
                point = new Point(i, j);
                if (this.getShapeCoordinates().contains(point)) {
                    break;
                }
                this.setColorCoordinates(point);
            }
        }
    }

    public Set<Point> getShapeCoordinates() {
        return shapeCoordinates;
    }

    public void setColorCoordinates(Point point) {
        this.colorCoordinates.add(point);
    }

}
