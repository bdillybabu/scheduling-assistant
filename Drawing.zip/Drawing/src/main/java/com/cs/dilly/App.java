package com.cs.dilly;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        Canvas canvas = new Canvas();
        Scanner scanner = new Scanner(System.in);

        while (true) {

            System.out.println("******************Enter Commands*********************");
            String input = scanner.nextLine();

            if ("Q".equalsIgnoreCase(input)) {
                System.out.println("Exit!");
                break;
            }

            try {
                canvas.receiveCommand(input);
            } catch (Exception e) {
                e.printStackTrace();
                break;
            }

        }
        scanner.close();
    }

}
