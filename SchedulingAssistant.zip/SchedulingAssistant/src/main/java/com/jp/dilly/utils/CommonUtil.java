package com.jp.dilly.utils;

import com.google.common.collect.Lists;
import com.jp.dilly.model.Talks;
import com.jp.dilly.model.Talks.Category;
import com.jp.dilly.model.Talks.Talk;
import com.jp.dilly.model.Track;
import com.jp.dilly.model.Track.Schedule;
import com.jp.dilly.service.Scheduler;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import static com.jp.dilly.constants.Constant.SPACE;
import static com.jp.dilly.constants.Constant.TIME_FORMAT;

public class CommonUtil {

    public static void printSchedule(Scheduler scheduler) {

        StringBuilder builder;
        DateTimeFormatter timeFormatter = DateTimeFormat.forPattern(TIME_FORMAT);

        for (Track track : scheduler.getTracks()) {
            System.out.println();
            builder = new StringBuilder();
            builder.append("Day ");
            builder.append(track.getDayNo());
            builder.append(" Track ");
            builder.append(track.getTrackNo());
            builder.append(":");
            System.out.println(builder.toString());
            for (Schedule schedule : track.getSchedules()) {
                if (schedule.isScheduled()) {
                    builder = new StringBuilder();
                    builder.append(timeFormatter.print(schedule.getStart()));
                    builder.append(SPACE);
                    builder.append(schedule.getDescription());
                    if (null != schedule.getType()) {
                        builder.append(SPACE);
                        builder.append(schedule.getType());
                    }
                    System.out.println(builder.toString());
                }
            }
        }
    }

    public static Map<Integer, List<Talk>> getMapByDuration(Talks talks) {
        Map<Integer, List<Talk>> map = new TreeMap<>();
        for (Talk talk : talks.getTalks()) {
            if (map.containsKey(talk.getType().getMinutes())) {
                map.get(talk.getType().getMinutes()).add(talk);
            } else {
                map.put(talk.getType().getMinutes(), Lists.newArrayList(talk));
            }
        }
        return ((TreeMap<Integer, List<Talk>>) map).descendingMap();
    }

    public static Map<Category, List<Talk>> getMapByCategory(Talks talks) {
        Map<Category, List<Talk>> map = new TreeMap<>();
        for (Talk talk : talks.getTalks()) {
            if (map.containsKey(talk.getType())) {
                map.get(talk.getType()).add(talk);
            } else {
                map.put(talk.getType(), Lists.newArrayList(talk));
            }
        }
        return map;
    }
}
