package com.jp.dilly.constants;

public class Constant {

    public static final String FIRST_TALK_TIME_WITHOUT_KEYNOTE = "09:00";
    public static final String FIRST_TALK_TIME = "09:30";
    public static final String LAST_TALK_TIME = "16:30";
    public static final String LAST_TALK_TIME_WITHOUT_CLOSING = "17:00";
    public static final String LUNCH_START_TIME = "12:30";
    public static final String LUNCH_END_TIME = "13:30";
    public static final String TEA_START_TIME = "15:00";
    public static final String TEA_END_TIME = "15:15";

    public static final String SPACE = " ";
    public static final String DATE_FORMAT = "MM/dd/yyyy";
    public static final String TIME_FORMAT = "HH:mm";
    public static final String LUNCH = "LUNCH";
    public static final String TEA = "TEA";
    public static final int MINIMUM_SCHEDULE_DURATION = 10;

    public static final String FIRST_DAY = "06/29/2019";
    public static final int NUMBER_OF_DAYS = 2;
    public static final String JSON_FILE = "json/talks.json";
}
