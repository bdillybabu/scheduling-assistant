package com.jp.dilly.service;

import com.google.common.collect.Lists;
import com.jp.dilly.model.Talks;
import com.jp.dilly.model.Talks.Talk;
import com.jp.dilly.model.Track;
import com.jp.dilly.model.Track.Schedule;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import static com.jp.dilly.constants.Constant.*;
import static com.jp.dilly.utils.CommonUtil.getMapByCategory;
import static com.jp.dilly.utils.CommonUtil.getMapByDuration;

public class Scheduler {

    static DateTimeFormatter dateFormatter = DateTimeFormat.forPattern(DATE_FORMAT);

    private DateTime date;
    private Integer dayNo;
    private List<Track> tracks;
    private Map<Integer, List<Talk>> talksByDuration;
    private Talks talks;

    public Scheduler(Talks talks, String date) {
        this.talks = talks;
        this.date = dateFormatter.parseDateTime(date);
    }

    public void scheduleDefault(Integer dayNo, Integer trackNo) {
        if (dayNo != 1) {
            this.date.plusDays(dayNo - 1);
        }
        this.dayNo = dayNo;
        this.generateDefaultTracks(trackNo);
    }

    /**
     * Generate default schedule template for a day for both schedule and unscheduled
     */
    public void generateDefaultTracks(Integer trackNo) {

        Track track = new Track(this.getDayNo(), this.getDate(), trackNo);

        Talk keyNoteTalk = getTalkByCategory(Talks.Category.KEYNOTE);
        Schedule keyNoteTalkTime = null;
        Schedule nextTalkTime;
        if (null != keyNoteTalk) {
            keyNoteTalkTime = new Schedule(this.getDate(), FIRST_TALK_TIME_WITHOUT_KEYNOTE, keyNoteTalk);
            nextTalkTime = new Schedule(this.getDate(), FIRST_TALK_TIME, LUNCH_START_TIME, Boolean.FALSE, StringUtils.EMPTY);
        } else {
            nextTalkTime = new Schedule(this.getDate(), FIRST_TALK_TIME_WITHOUT_KEYNOTE, LUNCH_START_TIME, Boolean.FALSE, StringUtils.EMPTY);
        }
        Schedule lunchTime = new Schedule(this.getDate(), LUNCH_START_TIME, LUNCH_END_TIME, Boolean.TRUE, LUNCH);
        Schedule afterNoonTime = new Schedule(this.getDate(), LUNCH_END_TIME, TEA_START_TIME, Boolean.FALSE, StringUtils.EMPTY);
        Schedule teaTime = new Schedule(this.getDate(), TEA_START_TIME, TEA_END_TIME, Boolean.TRUE, TEA);

        Talk closingTalk = getTalkByCategory(Talks.Category.CLOSING);
        Schedule closingTalkTime = null;
        Schedule lastTalkTime;
        if (null == closingTalk) {
            lastTalkTime = new Schedule(this.getDate(), TEA_END_TIME, LAST_TALK_TIME_WITHOUT_CLOSING, Boolean.FALSE, StringUtils.EMPTY);
        } else {
            lastTalkTime = new Schedule(this.getDate(), TEA_END_TIME, LAST_TALK_TIME, Boolean.FALSE, StringUtils.EMPTY);
            closingTalkTime = new Schedule(this.getDate(), LAST_TALK_TIME, closingTalk);
        }
        List<Schedule> schedules = track.getSchedules();
        if (null != keyNoteTalk) {
            schedules.add(keyNoteTalkTime);
        }
        schedules.add(nextTalkTime);
        schedules.add(lunchTime);
        schedules.add(afterNoonTime);
        schedules.add(teaTime);
        schedules.add(lastTalkTime);
        if (null != closingTalk) {
            schedules.add(closingTalkTime);
        }
        this.getTracks().add(track);
    }

    /**
     * Pick a talk based on Category
     */
    public Talk getTalkByCategory(Talks.Category category) {
        Map<Talks.Category, List<Talk>> talksByCategory = getMapByCategory(talks);
        Talk talk = null;
        if (talksByCategory.containsKey(category)) {
            talk = Lists.newLinkedList(talksByCategory.get(category)).removeFirst();
        }
        talks.getTalks().remove(talk);
        return talk;
    }

    /**
     * Schedule talks for unscheduled items
     */
    public void scheduleTalks(int dayNo, int trackNo) {

        talksByDuration = getMapByDuration(talks);

        List<Schedule> newSchedules;

        //for (Track track : this.getTracks()) {
        for (Track track : this.getTracks(trackNo, dayNo)) {

            newSchedules = new ArrayList<>();
            for (Schedule schedule : track.getSchedules()) {

                if (!schedule.isScheduled()) { //Assigning unscheduled talks

                    int duration = schedule.getDuration().intValue();
                    List<Talk> filteredTalks = getTalksForDuration(duration);

                    DateTime scheduleStartTime = schedule.getStart();

                    int endDuration = 0;
                    for (Talk talk : filteredTalks) {
                        endDuration = endDuration + talk.getType().getMinutes();
                        Schedule newSchedule = new Schedule(scheduleStartTime, talk);
                        scheduleStartTime = schedule.getStart().plusMinutes(endDuration);
                        newSchedules.add(newSchedule);
                    }
                    //Remove all scheduled talks
                    talks.getTalks().removeAll(filteredTalks);
                }

            }
            track.getSchedules().addAll(newSchedules);
        }
    }

    /**
     * Fetch talks that can be accomodated within a duration
     */
    public List<Talk> getTalksForDuration(int duration) {

        List<Talk> filteredTalks = new LinkedList<>();
        while (duration > 0) {
            if (duration < MINIMUM_SCHEDULE_DURATION) {
                break;
            }
            List<Integer> emptyKeys = new ArrayList<>();
            for (Map.Entry<Integer, List<Talk>> entry : talksByDuration.entrySet()) {
                if (entry.getKey() <= duration) {
                    if (entry.getValue().size() == 0) {
                        emptyKeys.add(entry.getKey());
                        continue;
                    }
                    duration = duration - entry.getKey();
                    filteredTalks.add(entry.getValue().get(0));
                    entry.getValue().remove(0);
                    break;
                }
            }
            //Once talk picked remove from the map for not be conisdered in next iteration
            for (Integer keys : emptyKeys) {
                talksByDuration.remove(keys);
            }
            //Break condition to exit if not talks available
            if (talksByDuration.entrySet().size() == 0) {
                break;
            }
        }
        return filteredTalks;
    }

    public DateTime getDate() {
        return date;
    }

    public Integer getDayNo() {
        return dayNo;
    }

    public List<Track> getTracks() {
        if (tracks == null) {
            tracks = new ArrayList<>();
        }
        return tracks;
    }

    public List<Track> getTracks(int trackNo, int dayNo) {
        List<Track> filteredTrack = new LinkedList<>();
        for (Track track : tracks) {
            if (track.getDayNo() == dayNo && track.getTrackNo() == trackNo) {
                filteredTrack.add(track);
            }
        }
        return filteredTrack;
    }
}
