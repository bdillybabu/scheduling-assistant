package com.jp.dilly.service;

import com.jp.dilly.model.Talks;
import com.jp.dilly.utils.JsonUtil;

import java.util.HashMap;
import java.util.Map;

import static com.jp.dilly.constants.Constant.*;
import static com.jp.dilly.utils.CommonUtil.printSchedule;

public class Conference {

    public static Map<Integer, Integer> trackMapForEachDay = new HashMap<>();

    public static void conferenceScheduler() {

        Talks talks = JsonUtil.parseJson(JSON_FILE, Talks.class);
        Scheduler scheduler = new Scheduler(talks, FIRST_DAY);

        int iteration = 1;
        //Schedule talks for days
        while (true) {

            int findDay = iteration % NUMBER_OF_DAYS;
            int dayNo = (findDay != 0) ? findDay : NUMBER_OF_DAYS;
            int dayTrack = getTrackNo(dayNo);

            scheduler.scheduleDefault(dayNo, dayTrack);
            scheduler.scheduleTalks(dayNo, dayTrack);

            iteration++;
            if (talks.getTalks().size() <= 0) { //Break out if no talk available to scheduling
                break;
            }
        }

        printSchedule(scheduler);
    }

    private static int getTrackNo(int dayNo) {
        int trackNo = 1;
        if (trackMapForEachDay.containsKey(dayNo)) {
            trackNo = trackMapForEachDay.get(dayNo) + 1;
        }
        trackMapForEachDay.put(dayNo, trackNo);
        return trackNo;
    }
}
