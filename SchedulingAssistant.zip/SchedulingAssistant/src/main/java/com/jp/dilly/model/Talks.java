package com.jp.dilly.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Talks {

    private List<Talk> talks;

    public List<Talk> getTalks() {
        return talks;
    }

    public enum Category {

        PANEL_DISCUSSION(60),
        LIGHTNING(10),
        REGULAR_TALK(30),
        KEYNOTE(30),
        WORKSHOP(60),
        CLOSING(30);

        private int minutes;

        Category(int minutes) {
            this.minutes = minutes;
        }

        public int getMinutes() {
            return minutes;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Talk {

        private Category type;
        private String description;
        private List<String> tags;
        private String title;

        public Category getType() {
            return type;
        }

        public void setType(Category type) {
            this.type = type;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public List<String> getTags() {
            return tags;
        }

        public void setTags(List<String> tags) {
            this.tags = tags;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }
    }
}
