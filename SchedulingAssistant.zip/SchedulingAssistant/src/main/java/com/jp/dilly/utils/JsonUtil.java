package com.jp.dilly.utils;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.google.common.io.Resources;

import java.io.IOException;
import java.nio.charset.Charset;

public class JsonUtil {

    private static ObjectMapper objectMapper = objectMapper();

    private static ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
        return mapper;
    }

    public static <T> T parseJson(String file, Class<T> clazz) {
        ObjectReader reader = objectMapper.reader(clazz);
        try {
            String jsonString = Resources.toString(Resources.getResource(file), Charset.defaultCharset());
            return reader.readValue(jsonString);
        } catch (IOException var3) {
            throw new RuntimeException(var3);
        }
    }

}
