package com.jp.dilly.model;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Track implements Comparable<Track> {

    private Integer dayNo;
    private DateTime date;
    private Integer trackNo;
    private List<Schedule> schedules;

    public Track(Integer dayNo, DateTime date, Integer trackNo) {
        this.dayNo = dayNo;
        this.date = date;
        this.trackNo = trackNo;
    }

    public DateTime getDate() {
        return date;
    }

    public Integer getDayNo() {
        return dayNo;
    }

    public Integer getTrackNo() {
        return trackNo;
    }

    public List<Schedule> getSchedules() {
        if (schedules == null) {
            schedules = new ArrayList<>();
        }
        Collections.sort(schedules, new Comparator<Schedule>() {
            @Override
            public int compare(Schedule o1, Schedule o2) {
                return o1.getStart().compareTo(o2.getStart());
            }
        });
        return schedules;
    }

    @Override
    public int compareTo(Track o) {
        int compareTrack = this.getTrackNo().compareTo(o.getTrackNo());
        if (compareTrack == 0) {
            return this.getDayNo().compareTo(o.getDayNo());
        }
        return compareTrack;
    }

    public static class Schedule {
        private DateTime start;
        private DateTime end;
        private boolean scheduled;
        private Long duration;
        private String description;
        private Talks.Category type;

        public Schedule(DateTime date, String time, Talks.Talk talk) {
            String[] startSplit = StringUtils.split(time, ":");
            this.setStart(date.withHourOfDay(Integer.parseInt(startSplit[0]))
                    .withMinuteOfHour(Integer.parseInt(startSplit[1]))
                    .withSecondOfMinute(0));
            this.setEnd(this.getStart().plusMinutes(talk.getType().getMinutes()));
            this.setDuration(getMinutes(this.getEnd(), this.getStart()));
            this.scheduled = Boolean.TRUE;
            this.description = talk.getDescription();
            this.type = talk.getType();
        }

        public Schedule(DateTime start, Talks.Talk talk) {
            this.setStart(start);
            this.setEnd(start.plusMinutes(talk.getType().getMinutes()));
            this.setDuration(getMinutes(this.getEnd(), this.getStart()));
            this.scheduled = Boolean.TRUE;
            this.description = talk.getDescription();
            this.type = talk.getType();
        }

        public Schedule(DateTime date, String start, String end, boolean scheduled, String description) {
            String[] startSplit = StringUtils.split(start, ":");
            String[] endSplit = StringUtils.split(end, ":");
            this.setStart(date.withHourOfDay(Integer.parseInt(startSplit[0]))
                    .withMinuteOfHour(Integer.parseInt(startSplit[1]))
                    .withSecondOfMinute(0));
            this.setEnd(date.withHourOfDay(Integer.parseInt(endSplit[0]))
                    .withMinuteOfHour(Integer.parseInt(endSplit[1]))
                    .withSecondOfMinute(0));
            this.setDuration(getMinutes(this.getEnd(), this.getStart()));
            this.scheduled = scheduled;
            this.description = description;
        }

        public Talks.Category getType() {
            return type;
        }

        public DateTime getStart() {
            return start;
        }

        public void setStart(DateTime start) {
            this.start = start;
        }

        public DateTime getEnd() {
            return end;
        }

        public void setEnd(DateTime end) {
            this.end = end;
        }

        public boolean isScheduled() {
            return scheduled;
        }

        public void setScheduled(boolean scheduled) {
            this.scheduled = scheduled;
        }

        public Long getDuration() {
            return duration;
        }

        public void setDuration(Long duration) {
            this.duration = duration;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        private Long getMinutes(DateTime end, DateTime start) {
            return (end.getMillis() - start.getMillis()) / (1000 * 60);
        }
    }

}
