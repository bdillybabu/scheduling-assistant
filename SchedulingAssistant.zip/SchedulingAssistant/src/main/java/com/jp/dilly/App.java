package com.jp.dilly;

import static com.jp.dilly.service.Conference.conferenceScheduler;

/**
 * Conference Scheduler
 */
public class App {


    public static void main(String[] args) {

        try {
            conferenceScheduler();
        } catch (Exception exception) {
            System.out.println("Conference Scheduling - Failed");
            exception.printStackTrace();
        }

        System.out.println("Conference Scheduling - Completed");
    }


}
